package application;




import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class TareaController {
	@FXML
	TextField texto;
	@FXML
	Label mostrarTexto;
	
	public void mostrar() {
		String textoCambiado = texto.getText().toString();
		mostrarTexto.setText(textoCambiado);
	}

	
}
